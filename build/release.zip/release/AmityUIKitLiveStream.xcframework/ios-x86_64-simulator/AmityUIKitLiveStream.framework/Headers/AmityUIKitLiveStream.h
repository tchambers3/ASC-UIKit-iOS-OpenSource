//
//  AmityUIKitLiveStream.h
//  AmityUIKitLiveStream
//
//  Created by Nutchaphon Rewik on 30/8/2564 BE.
//

#import <Foundation/Foundation.h>

//! Project version number for AmityUIKitLiveStream.
FOUNDATION_EXPORT double AmityUIKitLiveStreamVersionNumber;

//! Project version string for AmityUIKitLiveStream.
FOUNDATION_EXPORT const unsigned char AmityUIKitLiveStreamVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmityUIKitLiveStream/PublicHeader.h>


